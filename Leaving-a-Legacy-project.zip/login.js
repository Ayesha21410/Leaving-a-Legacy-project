const api_url = "https://retoolapi.dev/6570HK/data";

// Get the login form element
const loginForm = document.getElementById("loginForm");

// Add event listener to the form submit event
loginForm.addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent form submission

  // Call the login function when the form is submitted
  login();
});

// Function to handle login
async function login() {
  // Get the inputted email and password
  const email = document.getElementById("EmailText").value;
  const password = document.getElementById("PasswordText").value;

  // Validate email and password
  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  // Send a POST request to the login API
  try {
    const response = await fetch(api_url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ email, password })
    });

    if (response.ok) {
      const data = await response.json();
      const { success, message } = data;

      if (success) {
        alert("Login successful");

        // Set the session to logged in
        sessionStorage.setItem("userStatus", "loggedIn");

        // Redirect the user to the dashboard or another page
        window.location.href = "in.html";
      } else {
        alert(message);
      }
    } else {
      throw new Error("Login failed. Please try again.");
    }
  } catch (error) {
    alert(error.message);
  }
}