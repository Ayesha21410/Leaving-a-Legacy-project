// Fetch Geography quiz data
fetch('https://opentdb.com/api.php?amount=30&category=22&difficulty=medium&type=multiple')

  
  .then(response => response.json())
  .then(data => {
    const quizContainer = document.querySelector('.quiz-container');
    const timerContainer = document.createElement('div');
    timerContainer.classList.add('timer-container');
    quizContainer.appendChild(timerContainer);

    // Set the quiz duration in seconds
    const quizDuration = 900; // 5 minutes

    let timeLeft = quizDuration;
    let timerInterval;
    const startTime = Date.now(); // Track the start time

    // Function to start the timer
    function startTimer() {
      // Display initial time
      displayTime();

      // Start the timer interval
      timerInterval = setInterval(() => {
        timeLeft--;

        // Display updated time
        displayTime();

        // Check if time has run out
        if (timeLeft === 0) {
          clearInterval(timerInterval);
          handleQuizCompletion();
        }
      }, 1000);
    }

    // Function to display the remaining time
    function displayTime() {
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;

      const formattedTime = `${minutes}:${seconds.toString().padStart(2, '0')}`;
      timerContainer.textContent = `Time Left: ${formattedTime}`;
    }

    // Generate quiz HTML dynamically
    const questions = data.results;
    const userAnswers = []; // Array to store user's selected answers
    const correctAnswers = []; // Array to store correct answers

    questions.forEach((question, index) => {
      const questionElement = document.createElement('div');
      questionElement.classList.add('question');

      const questionText = document.createElement('p');
      questionText.textContent = question.question;
      questionElement.appendChild(questionText);

      const optionsList = document.createElement('ul');
      optionsList.classList.add('options');

      const options = [...question.incorrect_answers, question.correct_answer];
      options.sort(); // Sorting options alphabetically

      options.forEach(option => {
        const optionItem = document.createElement('li');

        const optionInput = document.createElement('input');
        optionInput.type = 'radio';
        optionInput.name = `question-${index}`;
        optionInput.value = option;
        optionItem.appendChild(optionInput);

        const optionLabel = document.createElement('label');
        optionLabel.textContent = option;
        optionItem.appendChild(optionLabel);

        optionsList.appendChild(optionItem);
      });

      questionElement.appendChild(optionsList);

      quizContainer.appendChild(questionElement);

      correctAnswers.push(question.correct_answer);
    });

    // Append the exit button after the last question
    const exitButton = document.createElement('button');
    exitButton.className = 'exit-btn';
    exitButton.textContent = 'Exit';
    quizContainer.appendChild(exitButton);
    // Event listener for exit button click
    exitButton.addEventListener('click', () => {
      window.location.href = 'index.html';
    });

    // Append the submit button after the exit button
    const submitButton = document.createElement('button');
    submitButton.type = 'submit';
    submitButton.className = 'submit-btn';
    submitButton.textContent = 'Submit';
    quizContainer.appendChild(submitButton);

    // Function to handle quiz completion
    function handleQuizCompletion() {
      const skippedQuestionNumbers = [];

      // Loop through each question
      questions.forEach((question, index) => {
        // Get the selected option for the current question
        const selectedOption = document.querySelector(`input[name='question-${index}']:checked`);

        // Check if an option is selected
        if (selectedOption) {
          // Get the selected answer
          const selectedAnswer = selectedOption.value;

          // Create an object to store the question and selected answer
          const userAnswer = {
            question: question.question,
            selectedAnswer: selectedAnswer
          };

          // Push the user's answer to the userAnswers array
          userAnswers.push(userAnswer);
        } else {
          skippedQuestionNumbers.push(index + 1);
        }
      });

      if (skippedQuestionNumbers.length > 0) {
        const messageElement = document.createElement('p');
        messageElement.style.color = 'red';

        if (skippedQuestionNumbers.length === 1) {
          messageElement.textContent = `You didn't answer Question ${skippedQuestionNumbers[0]}. Please answer it.`;
        } else {
          const lastSkippedQuestion = skippedQuestionNumbers.pop();
          let skippedQuestionsText = skippedQuestionNumbers.join(', ');

          if (skippedQuestionNumbers.length > 0) {
            skippedQuestionsText += ',';
          }

          messageElement.textContent = `You didn't answer Questions ${skippedQuestionsText} and ${lastSkippedQuestion}. Please answer them.`;
        }

        quizContainer.insertBefore(messageElement, submitButton);
        return; // Exit the function if there are skipped questions
      }

      // Save the user's selected answers to localStorage
      localStorage.setItem('userAnswers', JSON.stringify(userAnswers));

      // Save the correct answers to localStorage
      localStorage.setItem('correctAnswers', JSON.stringify(correctAnswers));

      // Redirect the user to the Result page
      window.location.href = 'Result.html';
    }

    // Event listener for submit button click
    submitButton.addEventListener('click', handleQuizCompletion);
    // Append the history quiz button to the navbar
    const navbar = document.querySelector('.navbar');

    const historyQuizButton = document.createElement('button');
    historyQuizButton.textContent = 'History Quiz';
    navbar.appendChild(historyQuizButton);
    

    // Start the timer
    startTimer();
  })
  .catch(error => {
    console.log('Error:', error);
  });

