

document.addEventListener('DOMContentLoaded', () => {
  const userAnswers = JSON.parse(localStorage.getItem('userAnswers'));
  const correctAnswers = JSON.parse(localStorage.getItem('correctAnswers'));

  const resultContainer = document.querySelector('.result-container');
  const detailedResultButton = document.querySelector('.Detailed-result');
  const submitButton = document.querySelector('.Submit-button');
// Add this line to define overallResultElement
  const overallResultElement = document.getElementById('overall-result');
  // Function to show the result summary
const showResultSummary = () => {
  // Clear the result container
  resultContainer.innerHTML = '';

  // Calculate the number of correct answers
  let correctCount = 0;
  userAnswers.forEach((userAnswer, index) => {
    if (userAnswer.selectedAnswer === correctAnswers[index]) {
      correctCount++;
    }
  });

  // Add the overall result statement
  const overallResult = document.createElement('p');
  overallResult.textContent = `Overall Result: ${correctCount}/${userAnswers.length} correct answers`;
  resultContainer.appendChild(overallResult);

  // Determine which quote to display
  let quote = '';
  if (correctCount >= 15) {
    quote = "Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful.  - Albert Schweitzer" 
  } else {
    quote = "Success is not final, failure is not fatal: It is the courage to continue that counts. -Winston Churchill" 
  }

  // Add the quote to the result container
  const quoteElement = document.createElement('p');
  quoteElement.textContent = quote;
  resultContainer.appendChild(quoteElement);

  // Add the heading
  const heading = document.createElement('h2');
  heading.textContent = 'Detailed Result Summary';
  resultContainer.appendChild(heading);


    // Validate the length of userAnswers and correctAnswers
    if (userAnswers.length !== correctAnswers.length) {
      const errorText = document.createElement('p');
      errorText.textContent = 'Error: The number of user answers does not match the number of correct answers.';
      resultContainer.appendChild(errorText);
      return;
    }

    userAnswers.forEach((userAnswer, index) => {
      const resultItem = document.createElement('div');
      resultItem.classList.add('result-item');

      const questionNumber = index + 1;
      const question = document.createElement('p');
      question.textContent = `Question ${questionNumber}: ${userAnswer.question}`;
      resultItem.appendChild(question);

      const userAnswerElement = document.createElement('p');
      userAnswerElement.textContent = `Your Answer: ${userAnswer.selectedAnswer}`;
      resultItem.appendChild(userAnswerElement);

      const correctAnswerElement = document.createElement('p');
      correctAnswerElement.textContent = `Correct Answer: ${correctAnswers[index]}`;
      resultItem.appendChild(correctAnswerElement);

      // Create a container for text and icon
      const correctnessContainer = document.createElement('div');
      correctnessContainer.classList.add('correctness-container');

      // Add text indicating correctness
      const correctnessText = document.createElement('p');
      if (userAnswer.selectedAnswer === correctAnswers[index]) {
        correctnessText.textContent = 'Correct!';
        correctnessText.classList.add('correct');
      } else {
        correctnessText.textContent = 'Wrong!';
        correctnessText.classList.add('wrong');
      }
      correctnessContainer.appendChild(correctnessText);

      // Add icon indicating correctness
      const correctnessIcon = document.createElement('i');
      if (userAnswer.selectedAnswer === correctAnswers[index]) {
        correctnessIcon.classList.add('fas', 'fa-check', 'correct');
      } else {
        correctnessIcon.classList.add('fas', 'fa-times', 'wrong');
      }
      correctnessContainer.appendChild(correctnessIcon);

      resultItem.appendChild(correctnessContainer);

      resultContainer.appendChild(resultItem);
    });

    // Add "Go to Home" button
    const goToHomeButton = document.createElement('button');
    goToHomeButton.textContent = 'Go to Home';
    goToHomeButton.classList.add('go-to-home-button');
    resultContainer.appendChild(goToHomeButton);

    // Add "Retry Quiz" button
    const retryQuizButton = document.createElement('button');
    retryQuizButton.textContent = 'Retry Quiz';
    retryQuizButton.classList.add('retry-quiz-button');
    resultContainer.appendChild(retryQuizButton);

    // Add event listener for "Go to Home" button
    goToHomeButton.addEventListener('click', () => {
      window.location.href = 'index.html';
    });

    // Add event listener for "Retry Quiz" button
    retryQuizButton.addEventListener('click', () => {
      window.location.href = 'Geography.html';
    });
  };

  // Event listener for Detailed Result button
  detailedResultButton.addEventListener('click', () => {
    showResultSummary();
  });

  // Event listener for Submit button
  submitButton.addEventListener('click', () => {
    // Implement your logic to submit the quiz here
  });
});

