// Store the instructions and rules as strings
const instructions = `Get ready to show off your knowledge! Each question in the quiz is like a mini challenge waiting to be conquered.

Brace yourself for some multiple-choice madness! Read each question carefully and trust your instincts. The answers are right there, waiting to be discovered.

Brace yourself for instant feedback! Whether you're right or wrong, you won't be kept in the dark. Immediate feedback will light up the bottom of your screen, guiding you on your quest for knowledge.

Every correct answer is a victory dance waiting to happen! Score 1 point for each correct response and feel the rush of accomplishment with every point earned.

Mistakes happen, but don't worry! If you stumble upon a wrong answer, it won't cost you any points. Learn from it, dust yourself off, and keep pushing forward.

Let's put your knowledge to the test and embark on this exciting journey together! Good luck awaits you as you dive into the quiz. May the odds be ever in your favor!`;

const rules = `No peeking! This quiz is your chance to shine on your own. So, resist the temptation to seek outside help. Let your knowledge be your superpower!

Keep those phones away! We know it's tempting to Google the answers, but let's keep it fair. No phones allowed during the quiz. Trust your gut and let your brain do the heavy lifting.

Cheaters never prosper! We have a zero-tolerance policy for cheating. This quiz is all about your abilities and what you've learned. So, play fair, and let your integrity shine through!

Time is of the essence! The clock is ticking. You'll need to think fast and answer each question within the given time limit. Challenge yourself to beat the clock and showcase your quick thinking!`;

// Manipulate the DOM to display the instructions and rules
const instructionsContent = document.getElementById("instructions-content");
const rulesContent = document.getElementById("rules-content");

const instructionsParagraphs = instructions.split("\n\n"); // Split by two newlines for empty line
for (const paragraph of instructionsParagraphs) {
  const pElement = document.createElement("p");
  
  // Add bullet point
  const bulletElement = document.createElement("span");
  bulletElement.textContent = "\u2022 ";
  pElement.appendChild(bulletElement);
  
  // Add instruction text
  const textElement = document.createElement("span");
  textElement.textContent = paragraph;
  pElement.appendChild(textElement);
  
  instructionsContent.appendChild(pElement);
}

const rulesList = document.createElement("ul");
const rulesItems = rules.split("\n\n"); // Split by two newlines for empty line
for (const item of rulesItems) {
  const liElement = document.createElement("li");
  liElement.textContent = item;
  rulesList.appendChild(liElement);
  
  // Add empty line
  const emptyLineElement = document.createElement("br");
  rulesList.appendChild(emptyLineElement);
}
rulesContent.appendChild(rulesList);

  
  
  
